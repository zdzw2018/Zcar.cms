﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTcms.Web.UI.Page
{
    public partial class index : Web.UI.BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Redirect("/admin/login.aspx");
        }
    }

}
